# required for Kodi to recognize the dir as a module
