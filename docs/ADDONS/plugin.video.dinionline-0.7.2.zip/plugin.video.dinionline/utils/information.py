# -*- coding: utf-8 -*-
"""
    DigiOnline Kodi addon
    Copyright (C) 2019 Mr Dini
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.
    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>
"""
text = """%s - v%s\n
[B]Nem hivatalos kiegészítő, használat kizárólag saját felelősségre![/B] A használatból adódó esetleges következményekért a fejlesztő nem vállal felelősséget.
A kiegészítő béta állapotú, egyes funkciók hiányozhatnak.
Hibákat bátran jelenteni, esetleges módosításokat eszközölni a következő platformokon lehetséges:
Kiegészítő githubja: https://github.com/movieshark/DigiOnline
Fórumtéma: https://prohardver.hu/tema/kodi_xbmc_kiegeszito_magyar_nyelvu_online_filmekhe/friss.html
[B]Ikonok, háttér:[/B]\n
Icons made by Freepik from www.flaticon.com
[I]- By Dini[/I]
"""

eula = "Az Elfogadom gombra kattintva alulírom, hogy megértettem és elfogadom a szolgáltató adatvédelmi szabályzatát: [CR]%s"
